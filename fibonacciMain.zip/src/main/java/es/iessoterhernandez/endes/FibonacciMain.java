package es.iessoterhernandez.endes;

public class FibonacciMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Fibonacci f1 = new Fibonacci("fibonacci 1",10); 
		f1.mostrarSerie();
		
		Fibonacci f2 = new Fibonacci();
		f2.setNombre("fibonacci 2");
		f2.setTama�o(10);
		f2.mostrarSerie();
		
		
	}

}
